package com.asterislabs.grapeappi2;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;

public class MainActivity extends BaseActivity implements View.OnClickListener {

    EditText et_usuario, et_contrasena;
    Button btn_aceptar, btn_salir;
    ImageButton ibtn_camara;
    ImageView iv_foto;
    private ActivityResultLauncher<Void> takePicturePreviewLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et_usuario = findViewById(R.id.et_usuario);
        et_contrasena = findViewById(R.id.et_password);
        btn_aceptar = findViewById(R.id.btn_aceptar);
        btn_salir = findViewById(R.id.btn_salir);
        ibtn_camara = findViewById(R.id.ibtn_camara);
        iv_foto = findViewById(R.id.iv_foto);

        btn_aceptar.setOnClickListener(this);
        btn_salir.setOnClickListener(this);

        takePicturePreviewLauncher = registerForActivityResult(
                new ActivityResultContracts.TakePicturePreview(),
                bitmap -> {
                    if (bitmap != null) {
                        iv_foto.setImageBitmap(bitmap);
                    } else {
                        Toast.makeText(this, "No se tomó ninguna foto", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        ibtn_camara.setOnClickListener(view -> takePicturePreviewLauncher.launch(null));
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btn_aceptar) {
            String usuario = et_usuario.getText().toString().trim();
            String contrasena = et_contrasena.getText().toString().trim();

            if (usuario.isEmpty() || contrasena.isEmpty()) {
                Toast.makeText(this, "Debes ingresar usuario y contraseña", Toast.LENGTH_SHORT).show();
            } else {
                Intent intent = new Intent(this, PrincipalActivity.class);
                startActivity(intent);
                finish();
            }
        } else if (v.getId() == R.id.btn_salir) {
            finish();
        }
    }
}