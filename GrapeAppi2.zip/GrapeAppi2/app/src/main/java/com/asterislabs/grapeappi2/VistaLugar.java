package com.asterislabs.grapeappi2;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class VistaLugar extends AppCompatActivity {

    private Lugar lugar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vista_lugar);

        // Configurar Toolbar si existe
       /* Toolbar toolbar = findViewById(R.id.toolbar);
        if (toolbar != null) {
            setSupportActionBar(toolbar);
            if (getSupportActionBar() != null) {
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            }
        }

        */

        // Recibir el lugar desde el intent
        Bundle extras = getIntent().getExtras();
        if (extras != null && extras.getSerializable("lugar") != null) {
            lugar = (Lugar) extras.getSerializable("lugar");
            if (lugar != null) {
                mostrarDetallesLugar();
            }
        } else {
            Toast.makeText(this, "No se recibió información del lugar", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void mostrarDetallesLugar() {
        if (lugar != null) {
            // Actualizar título
            if (getSupportActionBar() != null) {
                getSupportActionBar().setTitle(lugar.getNombre());
            }

            // Actualizar vistas
            TextView tvNombre = findViewById(R.id.nombre);
            TextView tvDireccion = findViewById(R.id.direccion);
           // TextView tvTelefono = findViewById(R.id.telefono);
            //RatingBar ratingBar = findViewById(R.id.ratingBar);
            ImageView ivFoto = findViewById(R.id.iv_foto);

            if (tvNombre != null) tvNombre.setText(lugar.getNombre());
            if (tvDireccion != null) tvDireccion.setText(lugar.getDireccion());
           // if (tvTelefono != null) tvTelefono.setText(String.valueOf(lugar.getTelefono()));
            //if (ratingBar != null) ratingBar.setRating(lugar.getValoracion());

            if (ivFoto != null) {
                int id = R.drawable.otros1;
                switch(lugar.getTipo()) {
                    case RESTAURANTE: id = R.drawable.restaurante1; break;
                    case BAR: id = R.drawable.bar1; break;
                    case ESPECTACULOS: id = R.drawable.espectaculo1; break;
                    case HOTEL: id = R.drawable.hotel1; break;
                    case COMPRAS: id = R.drawable.compras1; break;
                    case EDUCACION: id = R.drawable.escuela2; break;
                    case DEPORTE: id = R.drawable.deportes1; break;
                    case OTROS: id = R.drawable.otros1; break;
                }
                ivFoto.setImageResource(id);
            }
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}