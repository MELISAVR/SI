package com.asterislabs.grapeappi2;

import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.preference.EditTextPreference;
import androidx.preference.PreferenceFragmentCompat;

public class preferencias extends PreferenceFragmentCompat // Cambiar a no abstract
        implements androidx.preference.Preference.OnPreferenceChangeListener {

    EditTextPreference num_imagenes;

    @Override
    public void onCreatePreferences(@Nullable Bundle savedInstanceState, @Nullable String rootKey) {
        setPreferencesFromResource(R.xml.preferences, rootKey);
        num_imagenes = (EditTextPreference) findPreference("kprf_numero_imagenes");
        num_imagenes.setOnPreferenceChangeListener(this);

        // Establecer el summary inicial
        String currentValue = num_imagenes.getText();
        if (currentValue != null) {
            num_imagenes.setSummary(currentValue + " imágenes se mostrarán en la galería");
        }
    }

    @Override
    public boolean onPreferenceChange(@NonNull androidx.preference.Preference preferencia, Object valor_pref) {
        int valor;
        boolean exito = false;
        String pref = preferencia.getKey();
        if (pref.equals("kprf_numero_imagenes")) {
            try {
                valor = Integer.parseInt((String) valor_pref);
                if (valor >= 10 && valor <= 30) {
                    num_imagenes.setSummary(valor + " imágenes se mostrarán en la galería");
                    exito = true;
                } else {
                    Toast.makeText(requireContext(), "El valor debe estar entre 10 y 30", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Toast.makeText(requireContext(), "El valor debe ser un número", Toast.LENGTH_SHORT).show();
            }
        }
        return exito;
    }
}