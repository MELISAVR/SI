package com.asterislabs.grapeappi2;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class PlacesActivity extends BaseActivity implements View.OnClickListener {

    ImageButton ib_salir;
    private RecyclerView recyclerView;
    private AdaptadorLugares adaptador;
    private RecyclerView.LayoutManager layoutManager;
    private Spinner spTipo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_places);

        // Habilitar botón "atrás" en ActionBar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Lista de Lugares");
        }

        recyclerView = findViewById(R.id.recycler_view);
        spTipo = findViewById(R.id.sp_tipo);
        ib_salir = findViewById(R.id.ib_salir);

        // Obtener lugares globales
        LugaresVector lugares = RegistrarLugarActivity.getLugaresGlobal();

        // Configurar adaptador
        adaptador = new AdaptadorLugares(this, lugares);
        recyclerView.setAdapter(adaptador);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        // Configurar Spinner con filtro
        if (spTipo != null) {
            spTipo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    String tipoSeleccionado = parent.getItemAtPosition(position).toString();

                    // Aplicar filtro
                    adaptador.filtrarPorTipo(tipoSeleccionado);

                    // Mostrar mensaje
                    int cantidadFiltrada = adaptador.getItemCount();
                    if (tipoSeleccionado.equals("Todos")) {
                        Toast.makeText(PlacesActivity.this,
                                "Mostrando todos los lugares (" + cantidadFiltrada + ")",
                                Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(PlacesActivity.this,
                                "Filtro: " + tipoSeleccionado + " (" + cantidadFiltrada + " lugares)",
                                Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {}
            });
        }

        ib_salir.setOnClickListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Actualizar lista al regresar
        if (adaptador != null) {
            adaptador.actualizarLista();
            // Resetear filtro a "Todos"
            if (spTipo != null) {
                spTipo.setSelection(0);
            }
        }
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.ib_salir) {
            finish();
        }
    }
}