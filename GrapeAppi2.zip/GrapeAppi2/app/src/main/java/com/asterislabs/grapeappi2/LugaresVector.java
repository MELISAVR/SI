package com.asterislabs.grapeappi2;

import java.util.ArrayList;
import java.util.List;

public class LugaresVector implements Lugares {
    protected List<Lugar> vectorLugares;

    public LugaresVector() {
        vectorLugares = ejemploLugares();
    }

    private static ArrayList<Lugar> ejemploLugares() {
        ArrayList<Lugar> lugares = new ArrayList<>();

        lugares.add(new Lugar(
                "ITSZ",
                "Carretera Acuaco-Zacapoaxtla",
                -97.570057,   // longitud
                19.83057,     // latitud
                TipoLugar.EDUCACION,
                "foto_itsz",
                2333000,
                "https://www.itsz.edu.mx",
                "La mejor escuela",
                System.currentTimeMillis(),
                4.5f
        ));

        lugares.add(new Lugar(
                "Casa",
                "Av. 20 de Noviembre",
                -97.570057,
                19.83057,
                TipoLugar.OTROS,
                "foto_casa",
                2333000,
                "https://www.itsz.edu.mx",
                "Excelente lugar",
                System.currentTimeMillis(),
                4.0f
        ));

        // ---------------- 5 LUGARES EXTRA ----------------

        lugares.add(new Lugar(
                "Parque Central",
                "Centro de Zacapoaxtla",
                -97.59720,
                19.86610,
                TipoLugar.OTROS,
                "foto_parque",
                0,
                "https://zacapoaxtla.gob.mx",
                "com.asterislabs.grapeappi2.Lugar tranquilo para pasear",
                System.currentTimeMillis(),
                4.2f
        ));

        lugares.add(new Lugar(
                "Hospital General",
                "Carretera Zacapoaxtla – Xalacapan",
                -97.56900,
                19.87400,
                TipoLugar.OTROS,
                "foto_hospital",
                2222500,
                "https://salud.mx",
                "Atención médica 24/7",
                System.currentTimeMillis(),
                4.8f
        ));

        lugares.add(new Lugar(
                "Biblioteca Municipal",
                "Centro, Calle Hidalgo",
                -97.59740,
                19.86580,
                TipoLugar.EDUCACION,
                "foto_biblioteca",
                0,
                "https://biblioteca.gob.mx",
                "Excelente lugar para estudiar",
                System.currentTimeMillis(),
                4.6f
        ));

        lugares.add(new Lugar(
                "Restaurante La Cabaña",
                "Salida a Cuetzalan",
                -97.58230,
                19.85990,
                TipoLugar.RESTAURANTE,
                "foto_cabana",
                200000,
                "https://lacabanarestaurante.com",
                "Comida típica muy rica",
                System.currentTimeMillis(),
                4.7f
        ));

        lugares.add(new Lugar(
                "Mirador del Valle",
                "Camino al cerro de Tepetzintle",
                -97.60590,
                19.85050,
                TipoLugar.OTROS,
                "foto_mirador",
                0,
                "",
                "Vista panorámica impresionante",
                System.currentTimeMillis(),
                4.9f
        ));

        return lugares;
    }


    @Override
    public void añadir(Lugar lugar) {
        vectorLugares.add(lugar);

    }

    @Override
    public int crear() {
        Lugar lugar = new Lugar();
        vectorLugares.add(lugar);
        return vectorLugares.size() - 1;
    }

    @Override
    public void borrar(int id) {
        vectorLugares.remove(id);
    }

    @Override
    public int contar() {
        return vectorLugares.size();
    }

    @Override
    public void actualizar(int id, Lugar lugar) {
        vectorLugares.set(id, lugar);

    }

    @Override
    public Lugar buscar(int id) {
        if (id >= 0 && id < vectorLugares.size()) {
            return vectorLugares.get(id);
        }
        return null;
    }
}
