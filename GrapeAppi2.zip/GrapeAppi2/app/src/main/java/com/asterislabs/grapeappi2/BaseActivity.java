package com.asterislabs.grapeappi2;

import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class BaseActivity extends AppCompatActivity {

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_principal, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.ma_preferencias) {
            abrirActividad(ConfigurationActivity.class);
            return true;
        } else if (id == R.id.ma_acercaDe) {
            abrirActividad(AboutToActivity.class);
            return true;
        } else if (id == R.id.ma_salir) {
            // Salir de la app completamente
            finishAffinity(); // Cierra todas las activities
            return true;
        } else if (id == android.R.id.home) {
            // Botón "atrás" en ActionBar
            onBackPressed();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    protected void abrirActividad(Class<?> actividad) {
        Intent intent = new Intent(this, actividad);
        startActivity(intent);
    }
}