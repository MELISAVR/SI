package com.asterislabs.grapeappi2;

import android.os.Bundle;
import android.widget.ImageButton;

public class AboutToActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_to);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Acerca De");
        }

        ImageButton salir = findViewById(R.id.ib_salir_config);
        if (salir != null) {
            salir.setOnClickListener(v -> finish());
        }
    }
}