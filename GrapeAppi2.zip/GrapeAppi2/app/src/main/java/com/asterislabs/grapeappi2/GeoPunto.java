package com.asterislabs.grapeappi2;

public class GeoPunto {
    public  GeoPunto(double longitud, double latitud) {
        this.longitud = (float) longitud;
        this.latitud = (float) latitud;
    }
    public float getLongitud() {
        return longitud;
    }

    public void setLongitud(float longitud) {
        this.longitud = longitud;
    }

    private float longitud;

    public float getLatitud() {
        return latitud;
    }

    public void setLatitud(float latitud) {
        this.latitud = latitud;
    }

    private float latitud;



    @Override
    public String toString() {
        return "com.asterislabs.grapeappi2.GeoPunto{" +
                "longitud=" + longitud +
                ", latitud=" + latitud +
                '}';
    }
}

