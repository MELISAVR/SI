package com.asterislabs.grapeappi2;

public enum TipoLugar {
    RESTAURANTE ("Restaurante",2),
    BAR ("Bar", 3),
    ESPECTACULOS ("Espectáculo", 4),
    HOTEL ("Hotel", 5),
    COMPRAS ("Compras", 6),
    EDUCACION ("Educación", 7),
    DEPORTE ("Deporte", 8),
    OTROS ("Otros", 1 )
    ;
    private String texto;
    private int recurso;

    TipoLugar(String texto, int recurso) {
        this.texto = texto;
        this.recurso = recurso;
    }
    public String getTexto() {
        return texto;
    }
    public int getRecurso() {
        return recurso;
    }
    public String toString() {
        return texto;
    }


}
