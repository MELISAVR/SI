package com.asterislabs.grapeappi2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.preference.Preference;
import androidx.preference.PreferenceManager;

public class PrincipalActivity extends AppCompatActivity
        implements View.OnClickListener, Preference.OnPreferenceChangeListener {

    Button btn_Verlugares, btn_Conf, btn_AcercaDe;
    ImageButton ib_salir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_principal);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btn_Verlugares = findViewById(R.id.btn_Verlugares);
        btn_Conf = findViewById(R.id.btn_Conf);
        btn_AcercaDe = findViewById(R.id.btn_AcercaDe);
        ib_salir = findViewById(R.id.ib_salir);

        btn_Verlugares.setOnClickListener(this);
        btn_Conf.setOnClickListener(this);
        btn_AcercaDe.setOnClickListener(this);
        ib_salir.setOnClickListener(this);
    }

    @Override
    public void onClick(View vista) {
        int id = vista.getId();

        if (id == R.id.btn_Verlugares) {
            abrirActividad(PlacesActivity.class);
        } else if (id == R.id.btn_Conf) {
            abrirActividad(ConfigurationActivity.class);
        } else if (id == R.id.btn_AcercaDe) {
            abrirActividad(AboutToActivity.class);
        } else if (id == R.id.ib_salir) {
            finish();
        }
    }

    private void abrirActividad(Class<?> actividad) {
        Intent intento = new Intent(this, actividad);
        startActivity(intento);
    }

    public void mostrarPreferencias() {
        SharedPreferences preferencias = PreferenceManager.getDefaultSharedPreferences(this);
        boolean musica = preferencias.getBoolean("kprf_sonido", false);
        boolean imagenes = preferencias.getBoolean("kprf_visor_imagenes", false);
        String tipoGaleria = preferencias.getString("kprf_imagenes", "2");
        String numeroImagenes = preferencias.getString("kprf_numero_imagenes", "10");

        Toast.makeText(this,"musica: "+musica
                + "imagenes: "+imagenes
                + "numeroImagenes: "+numeroImagenes
                + "tipoGaleria: "+tipoGaleria,Toast.LENGTH_LONG).show();
    }

    @Override
    public boolean onPreferenceChange(@NonNull Preference preference, Object newValue) {
        return false;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_principal, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.ma_preferencias) {
            abrirActividad(ConfigurationActivity.class);
        } else if (id == R.id.ma_acercaDe) {
            abrirActividad(AboutToActivity.class);
        }
        return true;
    }
}