package com.asterislabs.grapeappi2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class PrincipalActivity extends BaseActivity implements View.OnClickListener {

    Button btn_Verlugares, btn_RegistrarLugar, btn_Conf, btn_AcercaDe;
    ImageButton ib_salir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);

        btn_Verlugares = findViewById(R.id.btn_Verlugares);
        btn_RegistrarLugar = findViewById(R.id.btn_RegistrarLugar);
        btn_Conf = findViewById(R.id.btn_Conf);
        btn_AcercaDe = findViewById(R.id.btn_AcercaDe);
        ib_salir = findViewById(R.id.ib_salir);

        btn_Verlugares.setOnClickListener(this);
        btn_RegistrarLugar.setOnClickListener(this);
        btn_Conf.setOnClickListener(this);
        btn_AcercaDe.setOnClickListener(this);
        ib_salir.setOnClickListener(this);
    }

    @Override
    public void onClick(View vista) {
        int id = vista.getId();

        if (id == R.id.btn_Verlugares) {
            abrirActividad(PlacesActivity.class);
        } else if (id == R.id.btn_RegistrarLugar) {
            abrirActividad(RegistrarLugarActivity.class);
        } else if (id == R.id.btn_Conf) {
            abrirActividad(ConfigurationActivity.class);
        } else if (id == R.id.btn_AcercaDe) {
            abrirActividad(AboutToActivity.class);
        } else if (id == R.id.ib_salir) {
            finish();
        }
    }
}