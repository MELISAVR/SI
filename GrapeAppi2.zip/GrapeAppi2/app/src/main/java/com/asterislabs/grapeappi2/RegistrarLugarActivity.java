package com.asterislabs.grapeappi2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.Toast;

public class RegistrarLugarActivity extends BaseActivity implements View.OnClickListener {

    EditText et_nombre, et_direccion, et_telefono, et_url, et_comentario;
    Spinner sp_tipo;
    RatingBar ratingBar;
    Button btn_guardar, btn_cancelar;
    ImageButton ib_salir;

    private static LugaresVector lugaresGlobal = new LugaresVector();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar_lugar);

        // Habilitar botón "atrás"
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Registrar Lugar");
        }

        et_nombre = findViewById(R.id.et_nombre);
        et_direccion = findViewById(R.id.et_direccion);
        et_telefono = findViewById(R.id.et_telefono);
        et_url = findViewById(R.id.et_url);
        et_comentario = findViewById(R.id.et_comentario);
        sp_tipo = findViewById(R.id.sp_tipo);
        ratingBar = findViewById(R.id.ratingBar);
        btn_guardar = findViewById(R.id.btn_guardar);
        btn_cancelar = findViewById(R.id.btn_cancelar);
        ib_salir = findViewById(R.id.ib_salir);

        btn_guardar.setOnClickListener(this);
        btn_cancelar.setOnClickListener(this);
        ib_salir.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();

        if (id == R.id.btn_guardar) {
            guardarLugar();
        } else if (id == R.id.btn_cancelar || id == R.id.ib_salir) {
            finish();
        }
    }

    private void guardarLugar() {
        String nombre = et_nombre.getText().toString().trim();
        String direccion = et_direccion.getText().toString().trim();
        String telefonoStr = et_telefono.getText().toString().trim();
        String url = et_url.getText().toString().trim();
        String comentario = et_comentario.getText().toString().trim();
        float valoracion = ratingBar.getRating();

        if (nombre.isEmpty()) {
            Toast.makeText(this, "Ingresa el nombre del lugar", Toast.LENGTH_SHORT).show();
            return;
        }

        if (direccion.isEmpty()) {
            Toast.makeText(this, "Ingresa la dirección", Toast.LENGTH_SHORT).show();
            return;
        }

        int telefono = 0;
        try {
            if (!telefonoStr.isEmpty()) {
                telefono = Integer.parseInt(telefonoStr);
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Teléfono inválido", Toast.LENGTH_SHORT).show();
            return;
        }

        int posicionTipo = sp_tipo.getSelectedItemPosition();
        TipoLugar tipo = obtenerTipoLugar(posicionTipo);

        Lugar nuevoLugar = new Lugar(
                nombre, direccion,
                -97.570057, 19.83057,
                tipo, "foto_default",
                telefono, url, comentario,
                System.currentTimeMillis(),
                valoracion
        );

        lugaresGlobal.añadir(nuevoLugar);

        Toast.makeText(this, "✅ Lugar guardado exitosamente", Toast.LENGTH_SHORT).show();
        finish();
    }

    private TipoLugar obtenerTipoLugar(int position) {
        switch (position) {
            case 0: return TipoLugar.RESTAURANTE;
            case 1: return TipoLugar.BAR;
            case 2: return TipoLugar.ESPECTACULOS;
            case 3: return TipoLugar.HOTEL;
            case 4: return TipoLugar.COMPRAS;
            case 5: return TipoLugar.EDUCACION;
            case 6: return TipoLugar.DEPORTE;
            default: return TipoLugar.OTROS;
        }
    }

    public static LugaresVector getLugaresGlobal() {
        return lugaresGlobal;
    }
}