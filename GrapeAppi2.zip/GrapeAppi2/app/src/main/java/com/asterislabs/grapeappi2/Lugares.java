package com.asterislabs.grapeappi2;

public interface Lugares {
    void añadir  (Lugar lugar); //añade el elemneto indicado
    int crear();// añade un elemento en blanco y devuelve su id
    void borrar (int id); //borra el elemento con el id indicado
    int contar(); //devuelve el numero de elementos registrados
    void actualizar (int id, Lugar lugar); //modifica un elemento
    Lugar buscar (int id); //devuelve el elemento dando su id

}
