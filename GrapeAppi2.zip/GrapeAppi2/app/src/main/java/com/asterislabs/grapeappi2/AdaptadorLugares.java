package com.asterislabs.grapeappi2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class AdaptadorLugares extends RecyclerView.Adapter<AdaptadorLugares.ViewHolder> {

    protected LugaresVector lugares;
    protected List<Lugar> lugaresFiltrados; // Nueva lista filtrada
    protected LayoutInflater inflador;
    protected Context contexto;
    private OnItemClickListener listener;

    public AdaptadorLugares(Context contexto, LugaresVector lugares) {
        this.contexto = contexto;
        this.lugares = lugares;
        this.inflador = LayoutInflater.from(contexto);

        // Inicialmente muestra todos los lugares
        this.lugaresFiltrados = new ArrayList<>();
        for (int i = 0; i < lugares.contar(); i++) {
            lugaresFiltrados.add(lugares.buscar(i));
        }
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView nombre, direccion;
        public ImageView foto;
        public RatingBar valoracion;

        public ViewHolder(View itemView) {
            super(itemView);
            nombre = itemView.findViewById(R.id.nombre);
            direccion = itemView.findViewById(R.id.direccion);
            foto = itemView.findViewById(R.id.foto);
            valoracion = itemView.findViewById(R.id.valoracion);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = inflador.inflate(R.layout.content_vista_lugar, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Lugar lugar = lugaresFiltrados.get(position);
        if (lugar != null) {
            personalizaVista(holder, lugar);

            holder.itemView.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onItemClick(position);
                }
            });
        }
    }

    public void personalizaVista(ViewHolder holder, Lugar lugar) {
        holder.nombre.setText(lugar.getNombre());
        holder.direccion.setText(lugar.getDireccion());

        int id = R.drawable.otros;
        switch(lugar.getTipo()) {
            case RESTAURANTE: id = R.drawable.restaurante1; break;
            case BAR: id = R.drawable.bar1; break;
            case ESPECTACULOS: id = R.drawable.espectaculo1; break;
            case HOTEL: id = R.drawable.hotel1; break;
            case COMPRAS: id = R.drawable.compras1; break;
            case EDUCACION: id = R.drawable.escuela2; break;
            case DEPORTE: id = R.drawable.deportes1; break;
            case OTROS: id = R.drawable.otros1; break;
        }

        holder.foto.setImageResource(id);
        holder.foto.setScaleType(ImageView.ScaleType.FIT_CENTER);
        holder.valoracion.setRating(lugar.getValoracion());
    }

    @Override
    public int getItemCount() {
        return lugaresFiltrados.size();
    }

    // Método para filtrar lugares por tipo
    public void filtrarPorTipo(String tipoSeleccionado) {
        lugaresFiltrados.clear();

        if (tipoSeleccionado.equals("Todos") || tipoSeleccionado.isEmpty()) {
            // Mostrar todos
            for (int i = 0; i < lugares.contar(); i++) {
                lugaresFiltrados.add(lugares.buscar(i));
            }
        } else {
            // Filtrar por tipo específico
            for (int i = 0; i < lugares.contar(); i++) {
                Lugar lugar = lugares.buscar(i);
                if (lugar != null && lugar.getTipo().getTexto().equals(tipoSeleccionado)) {
                    lugaresFiltrados.add(lugar);
                }
            }
        }

        notifyDataSetChanged();
    }

    // Método para actualizar toda la lista
    public void actualizarLista() {
        lugaresFiltrados.clear();
        for (int i = 0; i < lugares.contar(); i++) {
            lugaresFiltrados.add(lugares.buscar(i));
        }
        notifyDataSetChanged();
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }
}